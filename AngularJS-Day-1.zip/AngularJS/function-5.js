

testHello();

function testHello() {
    i=10;
    console.log("Welcome"); 
    console.log(new Date());
    
}

testHello();

// no error
// variable hoisting
console.log(i);
