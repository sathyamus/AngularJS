angular.module('MyApp.controllers')
    .controller('NewClockCtrl',['$scope','$interval',
        function ($scope,$interval) {
            'use strict';
           
         }]);