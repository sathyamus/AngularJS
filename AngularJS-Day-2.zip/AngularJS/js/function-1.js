


function testHello() {
    console.log("Welcome"); 
    console.log(new Date());
}

testHello();

