angular.module('MyApp.services')
    .value('DateService', new Date());

//angular.module('MyApp.services')
//    .constant('DateService', new Date());
